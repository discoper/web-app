import React, { useState, useEffect, useRef } from "react";
import styles from "../styles/Home.module.scss";
import pfp from "../public/blankpfp.jpg";
import useAuth from "../components/authContext";
import Router from "next/router";
import CopyToClipboard from "../components/CopyToClipboard";
import Link from "next/link";
function User() {
  const { currentUser, changeUsername } = useAuth();
  const [edit, setEdit] = useState(false);
  const usernameInput = useRef();
  const [err, setErr] = useState();
  const [username, setUsername] = useState(currentUser && currentUser.username);
  const [contentSection, setContentSection] = useState("");
  useEffect(() => {
    if (!currentUser) Router.push("/");
    if (usernameInput.current)
      usernameInput.current.style.width = `${
        (usernameInput.current.value.length + 1) * 14
      }px`;
  }, []);
  useEffect(() => {
    setContentSection(Router.query.section);
  }, [Router.query.section]);

  useEffect(() => {
    if (err) {
      setTimeout(() => {
        setErr("");
      }, 3000);
    }
  }, [err]);
  const handleInput = async () => {
    if (!edit) {
      usernameInput.current.focus();
      return setEdit(true);
    }
    try {
      if (username == currentUser.username) return setEdit(false);
      await changeUsername(username);
      setEdit(false);
    } catch (err) {
      console.log(err.response.data);
      setErr(err.response.data);
    }
  };
  const handleChange = (e) => {
    const { id, value } = e.target;
    if (value.length < 30) {
      setUsername(value);
      usernameInput.current.style.width = `${(value.length + 1) * 14}px`;
    }
  };
  return (
    <>
      {currentUser && (
        <div className={`${styles.paginaPerfil}`}>
          <div
            className={`${styles.cajaBlanca2} ${styles.fondoBlanco} ${styles.perfilInfo}`}
          >
            <>
              <div
                className={`${styles.profileImageViewer} ${styles.imagenPerfilPerfil}`}
                onClick={() => Router.push("/agregarImagen")}
              >
                <div
                  style={{
                    backgroundImage: `url(${
                      currentUser.pfp ? currentUser.pfp : pfp.src
                    })`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                    backgroundRepeat: "no-repeat",
                    height: "100%",
                    width: "100%",
                  }}
                ></div>
                <div className={styles.imagenPerfilHoverLink}>
                  <p className={styles.textLead}>Cambiar Foto de perfil</p>
                </div>
              </div>
              <div className={styles.errMessageSignIn}>
                <small>{err}</small>
              </div>
              <p className={styles.textLead}>Tu id de usuario</p>
              <CopyToClipboard value={currentUser.id} />
            </>
            <p>Tu link de Referido:</p>
            <CopyToClipboard
              value={`https://discoper.io/access?form=0&ref=${currentUser.user.uid}`}
            />
            <div className={styles.userLinks}>
              <Link
                href={"/user?section=referidos#referidos"}
                passHref
                shallow={true}
              >
                <div className={styles.userLink}>
                  <span className="material-symbols-outlined">group_add</span>
                  <p className={styles.textLead}>Referidos</p>
                </div>
              </Link>
              <Link href={"/changeEmail"}>
                <div className={styles.userLink}>
                  <span className="material-symbols-outlined">mail</span>
                  <p className={styles.textLead}>Cambia tu email</p>
                </div>
              </Link>
            </div>
            <div className={styles.statsPlaceHolder}>
              <h1 className={`${styles.secondaryTitle} ${styles.darkBlue}`}>
                Informacion y Configuracion del usuario
              </h1>
            </div>
          </div>
          {contentSection && contentSection === "referidos" ? (
            <Referidos />
          ) : (
            <div className={`${styles.cajaBlanca2} ${styles.perfilContenido}`}>
              <h1 className={styles.primaryTitle}>Contenido</h1>
            </div>
          )}
        </div>
      )}
    </>
  );
}
const Referidos = () => {
  const { currentUser } = useAuth();
  const { referidos } = currentUser;
  return (
    <>
      <div className={`${styles.cajaBlanca2} ${styles.perfilContenido}`}>
        <h1 className={`${styles.secondaryTitle} ${styles.m0}`} id="referidos">
          Referidos
        </h1>
        <hr />
        <div className={styles.referidosBox}>
          {referidos.length ? (
            <>
              {referidos.map((doc) => {
                return (
                  <div key={doc} className={styles.textLead}>
                    {doc}
                  </div>
                );
              })}
            </>
          ) : (
            <>
              <p className={styles.textLead}>
                No tienes ningun referido, copia tu link de referido e invita a
                amigos a unirse a discoper!
              </p>
            </>
          )}
        </div>
      </div>
    </>
  );
};
export default User;
