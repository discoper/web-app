"use strict";
exports.id = 488;
exports.ids = [488];
exports.modules = {

/***/ 1488:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6208);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_authContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4237);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5623);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_authContext__WEBPACK_IMPORTED_MODULE_3__]);
_components_authContext__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







// import { useBox } from "..";
function Register() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { signUp  } = (0,_components_authContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { 0: err , 1: setErr  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const recaptchaRef = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createRef();
    const { 0: register , 1: setRegister  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        email: "",
        password: "",
        confirmPass: "",
        captcha: false,
        termsAndConditions: false,
        creador: false
    });
    const createUser = async ()=>{
        setLoading(true);
        if (!register.email) {
            setLoading(false);
            return setErr("Coloca el correo");
        }
        if (!register.password) {
            setLoading(false);
            return setErr("Coloca la contrase\xf1a");
        }
        if (register.confirmPass !== register.password) {
            setLoading(false);
            return setErr("Contrase\xf1as no coinciden");
        }
        if (!register.captcha) {
            setLoading(false);
            return setErr("Commplete el captcha");
        }
        if (!register.termsAndConditions) {
            setLoading(false);
            return setErr("Acepte los terminos y condiciones");
        }
        try {
            await signUp(register.email, register.password, router.query.ref, register.creador);
            setLoading(false);
        } catch (error) {
            setErr(error.response.data);
            setLoading(false);
        }
    };
    const onReCAPTCHAChange = (captchaCode)=>{
        if (!captchaCode) {
            return;
        }
        setRegister({
            ...register,
            captcha: true
        });
    };
    const handleChange = (e)=>{
        const { id , value  } = e.target;
        setRegister((prevState)=>({
                ...prevState,
                [id]: value
            })
        );
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().form),
            id: "signIn",
            onSubmit: (e)=>{
                e.preventDefault();
                createUser();
            },
            children: [
                loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().loadingAccess)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().errMessageSignIn),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                        children: err
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().formInputArea),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            htmlFor: "email",
                            children: "Email"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "email",
                            name: "email",
                            id: "email",
                            required: true,
                            value: register.email,
                            onChange: handleChange,
                            placeholder: "Email"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().formInputArea),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            htmlFor: "password",
                            children: "Password"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "password",
                            name: "password",
                            id: "password",
                            value: register.password,
                            onChange: handleChange,
                            required: true,
                            placeholder: "Password"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().formInputArea),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            htmlFor: "confirmPassword",
                            children: "Confirm Password"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "password",
                            name: "confirmPass",
                            id: "confirmPass",
                            value: register.confirmPass,
                            onChange: handleChange,
                            required: true,
                            placeholder: "Confirm Password"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().dFlex)} ${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().w100)}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "checkbox",
                            className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().checkBox),
                            id: "termsAndConditions",
                            value: register.termsAndConditions,
                            onChange: handleChange
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "Acepto los ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    href: "/",
                                    children: "terminos y condiciones"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().dFlex)} ${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().w100)}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "checkbox",
                            className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().checkBox),
                            value: register.creador,
                            id: "creador",
                            onChange: handleChange
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Soy un creador"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_google_recaptcha__WEBPACK_IMPORTED_MODULE_4___default()), {
                    sitekey: "6LfhsN0gAAAAAC53b_32XmxTUrVM6W2VaeMOfJpj",
                    size: "normal",
                    onChange: onReCAPTCHAChange
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "submit",
                    className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default().primaryButton),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        children: "Registrate"
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Register);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;