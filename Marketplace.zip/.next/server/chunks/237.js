"use strict";
exports.id = 237;
exports.ids = [237];
exports.modules = {

/***/ 2049:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6208);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function Loading() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default().loadingContainer),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default().ldsRipple),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 4237:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ AuthProvider),
/* harmony export */   "Z": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7235);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2049);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_firebaseConfig__WEBPACK_IMPORTED_MODULE_2__]);
_firebaseConfig__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const AuthContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext();
function useAuth() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
};
function AuthProvider({ children  }) {
    const { 0: currentUser , 1: setCurrentUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const logIn = async (email, password, agregarImagen)=>{
        try {
            const user = await _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__/* .auth.signInWithEmailAndPassword */ .I8.signInWithEmailAndPassword(email, password);
            if (!user.user.emailVerified) throw {
                message: "Por favor verifica tu correo"
            };
            await axios__WEBPACK_IMPORTED_MODULE_4___default().post("/api/signInUser", {
                idToken: await user.user.getIdToken()
            });
            return agregarImagen ? next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/agregarImagen") : next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/");
        } catch (err) {
            if (err.message === "Por favor verifica tu correo") {
                next_router__WEBPACK_IMPORTED_MODULE_3___default().push(`/verifyEmail?email=${user.email}
          }`);
            }
            if (err.code === "auth/wrong-password") throw {
                message: "Datos invalidos"
            };
            if (err.code === "auth/user-not-found") throw {
                message: "Usuario no existe"
            };
            throw err;
        }
    };
    const changeEmail = async (email)=>{
        await currentUser.user.updateEmail(email);
    };
    const signUp = async (email, password, refLink, creador)=>{
        try {
            let tries = 0;
            while(true){
                if (tries == 3) break;
                try {
                    tries++;
                    const res = await axios__WEBPACK_IMPORTED_MODULE_4___default().post("/api/register", {
                        email,
                        password,
                        refLink,
                        creador
                    });
                    break;
                } catch (err) {
                    console.log(err);
                    if (err.response.data === "The email address is already in use by another account.") throw err;
                    throw {
                        response: {
                            data: "Algo salio mal, intente nuevamente"
                        }
                    };
                }
            }
            return next_router__WEBPACK_IMPORTED_MODULE_3___default().push(`/verifyEmail?email=${email}`);
        } catch (err) {
            console.log(err);
            throw err;
        }
    };
    const logOut = async (goToStart)=>{
        setLoading(true);
        await axios__WEBPACK_IMPORTED_MODULE_4___default().get("/api/sessionLogout");
        await _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__/* .auth.signOut */ .I8.signOut();
        setLoading(false);
        if (!goToStart) {
            return next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/");
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const unsubscribe = _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__/* .auth.onIdTokenChanged */ .I8.onIdTokenChanged(async (user)=>{
            if (user) {
                setLoading(true);
                try {
                    let tries = 0;
                    while(true){
                        if (tries == 3) break;
                        try {
                            tries++;
                            await axios__WEBPACK_IMPORTED_MODULE_4___default().post("/api/signInUser", {
                                idToken: await user.getIdToken()
                            });
                            break;
                        } catch (err) {
                            console.log(err);
                        }
                    }
                    const firestoreUserDoc = await _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__/* .firestore.collection */ .RZ.collection("users").doc(user.uid).get();
                    if (!user.emailVerified) {
                        setLoading(false);
                        logOut(true);
                        return next_router__WEBPACK_IMPORTED_MODULE_3___default().push(`/verifyEmail?email=${user.email}`);
                    }
                    setCurrentUser({
                        user,
                        ...firestoreUserDoc.data()
                    });
                    setLoading(false);
                } catch (err) {
                    console.log(err);
                    logOut();
                    setLoading(false);
                }
                return;
            }
            setCurrentUser(user);
            setLoading(false);
            console.log(user);
        });
        return unsubscribe;
    }, []);
    const changeUsername = async (newUsername)=>{
        await axios__WEBPACK_IMPORTED_MODULE_4___default().post("/api/changeUsername", {
            newUsername
        });
    };
    const value = {
        currentUser,
        changeUsername,
        changeEmail,
        logIn,
        logOut,
        signUp
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: value,
        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loading__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}) : children
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7235:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I8": () => (/* binding */ auth),
/* harmony export */   "RZ": () => (/* binding */ firestore),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var firebase_compat_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3773);
/* harmony import */ var firebase_compat_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4826);
/* harmony import */ var firebase_compat_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(741);
/* harmony import */ var firebase_compat_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(451);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_compat_app__WEBPACK_IMPORTED_MODULE_0__, firebase_compat_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_compat_firestore__WEBPACK_IMPORTED_MODULE_2__, firebase_compat_storage__WEBPACK_IMPORTED_MODULE_3__]);
([firebase_compat_app__WEBPACK_IMPORTED_MODULE_0__, firebase_compat_auth__WEBPACK_IMPORTED_MODULE_1__, firebase_compat_firestore__WEBPACK_IMPORTED_MODULE_2__, firebase_compat_storage__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const firebaseConfig = {
    apiKey: "AIzaSyDQw9ng8SRZ-MEYrdZJYAY-3TcF-j-Fv1I",
    authDomain: "discopersc-d84de.firebaseapp.com",
    projectId: "discopersc-d84de",
    storageBucket: "discopersc-d84de.appspot.com",
    messagingSenderId: "834630350211",
    appId: "1:834630350211:web:ad7262b6327e8ed3b432b6",
    measurementId: "G-7SLPZT3TX8"
};
// Initialize Firebase
firebase_compat_app__WEBPACK_IMPORTED_MODULE_0__["default"].initializeApp(firebaseConfig);
// firebase.auth().setPersistence(firebase.auth.Auth.Persistence.NONE);
const auth = firebase_compat_app__WEBPACK_IMPORTED_MODULE_0__["default"].auth();
const firestore = firebase_compat_app__WEBPACK_IMPORTED_MODULE_0__["default"].firestore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (firebase_compat_app__WEBPACK_IMPORTED_MODULE_0__["default"]);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;