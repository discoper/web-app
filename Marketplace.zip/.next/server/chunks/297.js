"use strict";
exports.id = 297;
exports.ids = [297];
exports.modules = {

/***/ 4066:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ojo.9df75474.png","height":2474,"width":2475,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5ElEQVR42j2PPUtCYQBGD/4JaQkS9TqkDUJfECT2RUNTS1huQUtNcW/gEKlLFA2tDa3ZULt4q2trVATVVLP+A7kvvI8iVx944MCZDkAMgOVcmhQeu4te9frCASAXOSYpAfaGsm5j+9paWrc7xwcloqXzYD9qDwruu+al0TGf9UdtxwsWSJHMFtwfvy3/r2eofYnz7yH/Pr0qm191SU7PukHrWc3/0HD2JurvQ277gTIzCy6AA+jytKnKXWgqjdBcVVsCbORgIkEZ0ByHmudIgOJT7AGMM1c2ihkSnAzurW0WnZHrA2wJXT/gyWuNAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 6297:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nodemailer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(206);
/* harmony import */ var _public_ojo_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4066);



const smtpTransport = nodemailer__WEBPACK_IMPORTED_MODULE_0___default().createTransport({
    host: "discoper.io",
    port: 465,
    secure: true,
    auth: {
        user: "noreply@discoper.io",
        pass: "Nosabras.1"
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (userEmail)=>{
    console.log("Nosabras.1");
    try {
        let link;
        let tries = 0;
        while(true){
            if (tries == 3) break;
            tries++;
            try {
                link = await _db__WEBPACK_IMPORTED_MODULE_1__/* ["default"].auth */ .Z.auth().generateEmailVerificationLink(userEmail);
                break;
            } catch (err) {
                throw err;
            }
        }
        const info = await smtpTransport.sendMail({
            from: "'Discoper Social Club' <noreply@discoper.io>",
            to: userEmail,
            subject: "Confirmacion de Correo Electronico",
            html: `<html>
  <div
    style="
      width: 100%;
      padding: 10px;
      background-color: #f7f7f7;
      display: flex;
      align-items: center;
      justify-content: center;
    "
  >
    <div class="" style="margin: 0 auto; text-align: center">
      <img
        src="https://discoper.io/_next/static/media/HorzLogo.66dc0461.png"
        style="
          width: 75%;
          text-align: center;
          max-width: 400px;
          min-width: 50px;
        "
        alt=""
        srcset=""
      />
    </div>
  </div>
  <div
    style="
      width: 100%;
      padding: 50px 10px;
      background-color: #1b1464;
      text-align: center;
    "
  >
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <div
          style="
            width: 50%;
            min-width: 200px;
            margin: 10px auto;
            background-color: #f7f7f7;
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0px 0px 50px 5px rgba(0, 0, 0, 0.2);
          "
        >
          <h1 style="margin: 20px 0px">
            Gracias por registrarte en Discoper.io!
          </h1>
          <p style="margin: 40px 0px">
            Haz click aca para verificar tu correo:
            <br />
          </p>
          <a
            style="
              background-color: #fc1ab8;
              border-radius: 2em;
              color: #f7f7f7;
              box-sizing: border-box;
              padding: 1em !important;
              border-style: none;
            "
            href="${link}"
            >Verificar</a
          >
        </div>
      </tr>
    </table>
  </div>
</html>
`
        });
        return info;
    } catch (err) {
        console.log(err);
        throw err;
    }
});


/***/ })

};
;