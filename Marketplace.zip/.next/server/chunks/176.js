"use strict";
exports.id = 176;
exports.ids = [176];
exports.modules = {

/***/ 8899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blankpfp.1f4315ff.jpg","height":720,"width":720,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAL8U0//EABsQAAEEAwAAAAAAAAAAAAAAABIAAhETFCRC/9oACAEBAAE/AMnfquaIQEdL/8QAGhEAAgIDAAAAAAAAAAAAAAAAAQIAAxETQf/aAAgBAgEBPwC9QmrHawZ//8QAGBEAAgMAAAAAAAAAAAAAAAAAABEBAnH/2gAIAQMBAT8AtCWH/9k="});

/***/ }),

/***/ 3610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/marketplace-white.f4b92c44.png","height":306,"width":307,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAcklEQVR42h3BQQoBARQA0C/FAWTvFE4guQE3wC2wYCHsrcRCanaWNBq5hJob2AnLN2reCz8TD1uJs41XKOzkUpmngyJ8rNwcnaTWvmGsra+nY6BtFBbqGpqGaqoW4SLKc13hHnJTM0t7LeEa3opyJlQkf8vjYSdAFe/PAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 835:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/marketplace.a9879c79.png","height":306,"width":307,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAhUlEQVR42k3Esa1BYRgA0O/lJe8NIFq/5O5gAhEbsAG2QEEh6FVCIRKdkhBiCYkNdIL2OqXinMhSetPlwowNW6bcQzlzbhw4cWVJHnoy5siKNQcmvEIdKjSoU6VJhXZoyD8FirT445dhaEd8GVAjOIdu9OgzYkGZYB96kH85ZaUU/GQpbT6EfDnlyHolJgAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 9101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ojo.9df75474.png","height":2474,"width":2475,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5ElEQVR42j2PPUtCYQBGD/4JaQkS9TqkDUJfECT2RUNTS1huQUtNcW/gEKlLFA2tDa3ZULt4q2trVATVVLP+A7kvvI8iVx944MCZDkAMgOVcmhQeu4te9frCASAXOSYpAfaGsm5j+9paWrc7xwcloqXzYD9qDwruu+al0TGf9UdtxwsWSJHMFtwfvy3/r2eofYnz7yH/Pr0qm191SU7PukHrWc3/0HD2JurvQ277gTIzCy6AA+jytKnKXWgqjdBcVVsCbORgIkEZ0ByHmudIgOJT7AGMM1c2ihkSnAzurW0WnZHrA2wJXT/gyWuNAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 2671:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ojoAnimado.4ff5b0bd.gif","height":500,"width":500});

/***/ }),

/***/ 2308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ojoNegativo.9147f424.png","height":2147,"width":2144,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABA0lEQVR42h2Ky0rDUBiE/6WPoAvFlclOH8Sd+CC+gKIrkSIIQnGjuKjiRsQ7pZAToymNpMRL7cVUoWCrTU9bY9Jwji2jycDA8H1DcfptrvRFyMKhkL6MJI98FvS+lURWKxWlxdudQbmJn607+JsGunYdjdZHp1arKuS+vzH3ooDMdEosbtex8N/9sXVRPjbQ/PpkdHl0KueJQLuPoDUHsxvPoL0nxMy40iRlc0xScnAws2xhbvU+2TG7NS1Jo9FQKxZcTE0eCEp7oB0PE+MZYedfAUAnKX7VKAp4yWkgveIgtWTB1F/Q7Xk8DAYqxXlwSqpdzOvazbU8OTuU2dy5pjMzkX+AxK4TE6aDnQAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 8176:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useNav),
/* harmony export */   "e": () => (/* binding */ NavbarWrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6208);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _authContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4237);
/* harmony import */ var _public_ojo_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9101);
/* harmony import */ var _public_ojoAnimado_gif__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2671);
/* harmony import */ var _public_ojoNegativo_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2308);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _public_blankpfp_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8899);
/* harmony import */ var _public_marketplace_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(835);
/* harmony import */ var _public_marketplace_white_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3610);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_authContext__WEBPACK_IMPORTED_MODULE_2__]);
_authContext__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const NavContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext();
function useNav() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(NavContext);
};
function NavbarWrapper({ children  }) {
    const { 0: eyeAnimation , 1: setEyeAnimation  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: pfpMenuToggler , 1: setPfpMenuToggler  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: eye , 1: setEye  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_public_ojo_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"].src */ .Z.src);
    const { 0: scrollTop , 1: setScrollTop  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { currentUser , logOut  } = (0,_authContext__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    const { 0: desktopScreen , 1: setDesktopScreen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const app = ()=>{
            if (!eyeAnimation) return;
            setEye(_public_ojoAnimado_gif__WEBPACK_IMPORTED_MODULE_4__/* ["default"].src */ .Z.src);
            setTimeout(()=>{
                setEye(_public_ojo_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"].src */ .Z.src);
            }, 830);
            setEyeAnimation(false);
        };
        return app();
    }, [
        eyeAnimation
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (window.location.pathname !== "/") {
            setScrollTop(true);
        }
        const onScroll = (e)=>{
            if (window.location.pathname === "/") setScrollTop(e.target.documentElement.scrollTop > 0);
        };
        window.addEventListener("scroll", onScroll);
        return ()=>window.removeEventListener("scroll", onScroll)
        ;
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const onHashChangeStart = (url)=>{
            setPfpMenuToggler(false);
            setEyeAnimation(true);
            if (url !== "/") {
                setScrollTop(true);
            }
        };
        router.events.on("routeChangeStart", onHashChangeStart);
        return ()=>{
            router.events.off("routeChangeStart", onHashChangeStart);
        };
    }, [
        router.events
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        function updateSize() {
            setDesktopScreen(window.innerWidth < 600);
        }
        window.addEventListener("resize", updateSize);
        return ()=>window.removeEventListener("resize", updateSize)
        ;
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().navbar)} ${scrollTop && (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().navLight)}`,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().navSection)} links`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                href: "https://marketplace.discoper.io/",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: !scrollTop && !desktopScreen ? _public_marketplace_white_png__WEBPACK_IMPORTED_MODULE_9__/* ["default"].src */ .Z.src : _public_marketplace_png__WEBPACK_IMPORTED_MODULE_8__/* ["default"].src */ .Z.src,
                                            alt: ""
                                        }),
                                        !currentUser && !desktopScreen && "Marketplace"
                                    ]
                                })
                            }),
                            currentUser ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/user",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "account_circle"
                                                }),
                                                "Mi espacio"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/user?section=referidos",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "group_add"
                                                }),
                                                "Mis referidos"
                                            ]
                                        })
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/#funcionamiento",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "engineering"
                                                }),
                                                !desktopScreen && "Funcionamiento"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/#referidos",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "group_add"
                                                }),
                                                !desktopScreen && "Referidos"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/#seguridad",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "security"
                                                }),
                                                !desktopScreen && "Seguridad"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/#team",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "groups"
                                                }),
                                                !desktopScreen && "Equipo"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/#preguntas",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "question_mark"
                                                }),
                                                !desktopScreen && "Preguntas"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: "/whitepaper",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "material-symbols-outlined",
                                                    children: "description"
                                                }),
                                                !desktopScreen && "Whitepapper"
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().logoNav),
                        onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_10___default().push("/")
                        ,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: scrollTop ? eye : _public_ojoNegativo_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"].src */ .Z.src,
                            alt: "",
                            srcSet: ""
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().buttons)}`,
                        children: currentUser ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().pfpContainer),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    onClick: ()=>setPfpMenuToggler(!pfpMenuToggler)
                                    ,
                                    className: `${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().profileImageViewer)} ${(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().pfp)}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            backgroundImage: `url(${currentUser.pfp ? currentUser.pfp : _public_blankpfp_jpg__WEBPACK_IMPORTED_MODULE_7__/* ["default"].src */ .Z.src})`,
                                            backgroundSize: "cover",
                                            backgroundPosition: "center",
                                            backgroundRepeat: "no-repeat",
                                            height: "100%",
                                            width: "100%"
                                        }
                                    })
                                }),
                                pfpMenuToggler && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().pfpLinkContainer),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().pfpLink),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                href: "/user",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    children: "Perfil"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().pfpLink),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                onClick: ()=>logOut()
                                                ,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    children: "Cerrar Sesi\xf3n"
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    href: "/access?form=1",
                                    passHref: true,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().thirdButton),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Ingresa"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    href: "/access?form=0",
                                    passHref: true,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_11___default().primaryButton),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Registrate"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavContext.Provider, {
                value: {
                    setEyeAnimation,
                    eyeAnimation
                },
                children: children
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;