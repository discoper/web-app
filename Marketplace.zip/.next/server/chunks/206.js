"use strict";
exports.id = 206;
exports.ids = [206];
exports.modules = {

/***/ 206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ db)
});

// EXTERNAL MODULE: external "firebase-admin"
var external_firebase_admin_ = __webpack_require__(2509);
var external_firebase_admin_default = /*#__PURE__*/__webpack_require__.n(external_firebase_admin_);
;// CONCATENATED MODULE: ./utils/db/discopersc-d84de-firebase-adminsdk-nnnni-12c1caafc6.json
const discopersc_d84de_firebase_adminsdk_nnnni_12c1caafc6_namespaceObject = JSON.parse('{"type":"service_account","project_id":"discopersc-d84de","private_key_id":"12c1caafc63768f05e29a8f5ee5d9bb821d5cc5c","private_key":"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC3g2tQ7O97FUCk\\n1D0KQytcHRPvygs0A2A57+HaAV9/XurXTustN/DjG8v7j1K84oaOcXlgr6TlFOAp\\npveEwlS7Zu7HKwRSkRiqAnDZ1/SBCi4MgmbTG2aAQiT5rG/jY3SvRBOIgeZOD6MN\\nxY7uKFPMzjr4BMZsgBH8rglYmQNzxAAbd0oR83QDJ2rt/G4UEUJuCo6isJ8UlB1l\\nCX/dPZLahWRJeSqmGHNZKLC/FHyiGZbW5qCRhGX5q9SNS0KmHSG+i6f1IdH24+RG\\nJMMbHS2tXGRPWnDehf2jh4cYSWqm0rh6cA2lTaqz4bcZsUcuWf9/0bBlJnQxvdWb\\nkeXCpg7LAgMBAAECggEAF9CWsdWlow1C1SvJJhafFGDzpY0h6g88GBiwxbf4OtEd\\nscZHOm2FixDK5muW5aCSAf8+LKrD6on3KICco3O38j/tNxc2hDkvKwo5DJQmt0OT\\nw+zSR41z6QDBx/g1kZvmWG5XCJfZmYIUULpgDjkD3agFEArymGxVqTsJRyBISef1\\nKCpOF37kdD6o9Jubw4DZieahHKjg4You/jTImjv2fVKxRIaELPt0mnv5jWqZ7XMB\\nRzpGo6mB8kadB0E3wDmFKwH82Puw2CIzioHu3uyQDR8PbqvNgbX/AF9VmOVQcMs/\\nyMFOFWc5Tt0D0HAQzrfE9WY4iDiO8vuxQI+MQ5bAPQKBgQDhM6A3D523NocdEEoJ\\niVz+gGoTxmF5ponLxonszmjX1e8mjUI04mcpVT4BJCR97FrdJ85ty5YgGBHuVn7m\\n/wGGuEiZW6d1hgl5jvqIdmVjGx//EU8CtI1Kmg+w2PVglT2dz2nT0Wj2xHeB4fEp\\n2bSGweXvQuZmHOaXL70sfz2ZrQKBgQDQnEYeDpdg0/oxgNRrlPwvLSi1o2Jjpm07\\nswDm8UudqpNnabIQrKGvNxCyYfzXsXAKa/BItVIkrUZNCpu5tWhPWdOMh+7nz8OJ\\nAqmyzdUOBV9Co81ti+YBbDfE0oCiF9pJszQ23del3uFFLCfDbUgGNZSGcIOOKv7b\\n7LZfYQbJVwKBgQCeZ4PgdvmG77HmPZj2UEq7MXRr6HST7xKp5UMK8L1KZE7NnTre\\nnAnYRv9QKi4I7QGU4fUPwc4dURD7xpeIwAJA0ssuJAwMXHW5rVqINk9mgKPm9DPR\\nQVLJEMjMqi8e+prWsBhOR9Q/Dz7Iezb5KwsSZrznqPULCnUgDxJPhEi+GQKBgDEQ\\ncFVlbSky8idue4eKFP4riuWdtehmHk7qPQ4UNoqwsdaiv2S4lZaWRvENpuA8NXPe\\nCzeundFOh7hbBGFbT1tKbz0gQ4p2DTFOVQde7ftMPCl6STi4rLIs97jtIZ/+KDMp\\nWOCGsM+saiNQzVFjhIshUvuDvw1TA3pKZGJueaAlAoGBAND7IiBdT0OXGs/5Tj8W\\nAcncGUJvDDnK2P9b4Yao0LPZSD2/bxLwtgPN9xvPsTQIkiIB1SRhYHVNYymzm6sr\\nFB0MKzv5PBxtAtZQ4h6z5e45+WcuzbjyU4sVCmSmDJJhqIivW0lVF7tCYck5xXEr\\nCtorXmb1y+uf0laE6RDqfVWs\\n-----END PRIVATE KEY-----\\n","client_email":"firebase-adminsdk-nnnni@discopersc-d84de.iam.gserviceaccount.com","client_id":"108874140044952245140","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_x509_cert_url":"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-nnnni%40discopersc-d84de.iam.gserviceaccount.com"}');
;// CONCATENATED MODULE: ./utils/db/index.js


if (!(external_firebase_admin_default()).apps.length) {
    try {
        external_firebase_admin_default().initializeApp({
            credential: external_firebase_admin_default().credential.cert(discopersc_d84de_firebase_adminsdk_nnnni_12c1caafc6_namespaceObject)
        });
    // admin.auth().setPersistence(firebase.auth.Auth.Persistence.NONE);
    } catch (error) {
        console.log("Firebase admin initialization error", error.stack);
    }
}
/* harmony default export */ const db = ((external_firebase_admin_default()));


/***/ })

};
;