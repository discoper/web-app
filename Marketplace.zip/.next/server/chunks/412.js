"use strict";
exports.id = 412;
exports.ids = [412];
exports.modules = {

/***/ 1412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6208);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const FadeInSection = ({ children , className  })=>{
    const domRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { 0: isVisible , 1: setVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let previousY = 0;
        let previousRatio = 0;
        const observer = new IntersectionObserver(([entries])=>{
            if (entries.isIntersecting) {
                // Not possible to set it back to false like this:
                setVisible(true);
                // No need to keep observing:
                return observer.unobserve(domRef.current);
            }
        }, {
            rootMargin: "-20% 0px -20% 0px"
        });
        observer.observe(domRef.current);
        return ()=>{
            if (domRef.current) observer.unobserve(domRef.current);
        };
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: domRef,
        className: `${isVisible ? (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default().fadeIn) : (_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default().fade)} ${className}`,
        style: {
            transition: "margin 700ms"
        },
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FadeInSection);


/***/ })

};
;