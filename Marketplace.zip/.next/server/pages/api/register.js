"use strict";
(() => {
var exports = {};
exports.id = 553;
exports.ids = [553];
exports.modules = {

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 3348:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ register)
/* harmony export */ });
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(206);
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nodemailer__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_sendVerificationEmail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6297);



async function register(req, res) {
    try {
        const user = await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].auth */ .Z.auth().createUser({
            email: req.body.email,
            password: req.body.password
        });
        try {
            await (0,_utils_sendVerificationEmail__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(user.email);
            const userDocRef = _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].firestore */ .Z.firestore().collection("users").doc(user.uid);
            if (req.body.refLink) {
                const referedRef = _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].firestore */ .Z.firestore().collection("users").doc(req.body.refLink);
                _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].firestore */ .Z.firestore().runTransaction((transaction)=>{
                    return transaction.get(referedRef).then((snapshot)=>{
                        transaction.set(userDocRef, {
                            referidos: [],
                            creador: req.body.creador ? req.body.creador : false,
                            date: new Date().getDate(),
                            id: ("" + new Date().getMilliseconds()).slice(0, -8)
                        });
                        if (!snapshot.exists) return;
                        let referedUserArray = snapshot.get("referidos");
                        referedUserArray.push(req.body.user.uid);
                        return transaction.set(referedRef, {
                            referidos: referedUserArray
                        }, {
                            merge: true
                        });
                    });
                });
            } else {
                userDocRef.set({
                    referidos: [],
                    creador: req.body.creador ? req.body.creador : false,
                    date: new Date(),
                    id: ("" + new Date().getTime()).slice(5)
                });
            }
        } catch (err) {
            await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].auth */ .Z.auth().deleteUser(user.uid);
            console.log(err);
        }
        res.status(200).send();
    } catch (err) {
        console.log(err);
        res.status(400).send(err.message);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [206,297], () => (__webpack_exec__(3348)));
module.exports = __webpack_exports__;

})();