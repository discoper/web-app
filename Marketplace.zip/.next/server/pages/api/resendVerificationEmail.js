"use strict";
(() => {
var exports = {};
exports.id = 705;
exports.ids = [705];
exports.modules = {

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 5006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ resendVerificationEmail)
/* harmony export */ });
/* harmony import */ var _utils_sendVerificationEmail__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6297);

async function resendVerificationEmail(req, res) {
    try {
        const info = await (0,_utils_sendVerificationEmail__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(req.body.email);
        console.log(info);
        res.send(200);
    } catch (err) {
        console.log(err);
        res.status(400).send("Algo salio mal, intente nuevamente");
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [206,297], () => (__webpack_exec__(5006)));
module.exports = __webpack_exports__;

})();