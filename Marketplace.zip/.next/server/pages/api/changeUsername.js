"use strict";
(() => {
var exports = {};
exports.id = 247;
exports.ids = [247];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ changeUsername)
});

// EXTERNAL MODULE: ./utils/db/index.js + 1 modules
var db = __webpack_require__(206);
// EXTERNAL MODULE: external "cookie"
var external_cookie_ = __webpack_require__(4802);
var external_cookie_default = /*#__PURE__*/__webpack_require__.n(external_cookie_);
;// CONCATENATED MODULE: ./utils/sessionFunction/index.js

async function checkUser(sessionCookie) {
    return await db/* default.auth */.Z.auth().verifySessionCookie(sessionCookie, true).then((decodedClaims)=>{
        return decodedClaims;
    }).catch((error)=>{
        return error;
    });
};

;// CONCATENATED MODULE: ./pages/api/changeUsername.js



async function changeUsername(req, res) {
    const user = await checkUser(external_cookie_default().parse(req.headers.cookie).session);
    const userRef = await db/* default.firestore */.Z.firestore().collection("users").doc(user.uid);
    const match = await db/* default.firestore */.Z.firestore().collection("users").where("username", "==", req.body.newUsername);
    try {
        await db/* default.firestore */.Z.firestore().runTransaction(async (transaction)=>{
            return transaction.get(match).then((usernameMatch)=>{
                if (usernameMatch.empty) {
                    return transaction.update(userRef, {
                        username: req.body.newUsername
                    });
                }
                throw "Nombre de usuario ya escogido";
            });
        });
        res.send(200);
    } catch (err) {
        res.status(400).send(err);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [206], () => (__webpack_exec__(856)));
module.exports = __webpack_exports__;

})();