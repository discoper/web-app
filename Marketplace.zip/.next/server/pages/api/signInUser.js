"use strict";
(() => {
var exports = {};
exports.id = 751;
exports.ids = [751];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 2713:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ signInUser)
/* harmony export */ });
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(206);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_1__);


async function signInUser(req, res) {
    const idToken = req.body.idToken;
    const expiresIn = 60 * 60 * 1000;
    await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].auth */ .Z.auth().createSessionCookie(idToken, {
        expiresIn
    }).then((sessionCookie)=>{
        try {
            const options = {
                maxAge: expiresIn,
                httpOnly: true
            };
            res.setHeader("Set-Cookie", cookie__WEBPACK_IMPORTED_MODULE_1___default().serialize("session", sessionCookie, options));
            res.statusCode = 200;
            res.end(JSON.stringify({
                status: "success"
            }));
        } catch (err) {
            console.log(err);
            res.status(401).send(err);
        }
    }).catch((error)=>{
        console.log(error);
        res.status(401).send(error.message);
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [206], () => (__webpack_exec__(2713)));
module.exports = __webpack_exports__;

})();